tmp/NtupleReader.o: src/NtupleReader.cc include/NtupleReader.hh \
  /opt/homebrew/Cellar/root/6.34.08_1/include/root/TTree.h \
  /opt/homebrew/Cellar/root/6.34.08_1/include/root/Compression.h \
  /opt/homebrew/Cellar/root/6.34.08_1/include/root/RtypesCore.h \
  /opt/homebrew/Cellar/root/6.34.08_1/include/root/ROOT/RConfig.hxx \
  /opt/homebrew/Cellar/root/6.34.08_1/include/root/ROOT/../RVersion.h \
  /opt/homebrew/Cellar/root/6.34.08_1/include/root/ROOT/RVersion.hxx \
  /opt/homebrew/Cellar/root/6.34.08_1/include/root/RConfigure.h \
  /opt/homebrew/Cellar/root/6.34.08_1/include/root/DllImport.h \
  /opt/homebrew/Cellar/root/6.34.08_1/include/root/ROOT/TIOFeatures.hxx \
  /opt/homebrew/Cellar/root/6.34.08_1/include/root/Rtypes.h \
  /opt/homebrew/Cellar/root/6.34.08_1/include/root/strtok.h \
  /opt/homebrew/Cellar/root/6.34.08_1/include/root/strlcpy.h \
  /opt/homebrew/Cellar/root/6.34.08_1/include/root/snprintf.h \
  /opt/homebrew/Cellar/root/6.34.08_1/include/root/TGenericClassInfo.h \
  /opt/homebrew/Cellar/root/6.34.08_1/include/root/TSchemaHelper.h \
  /opt/homebrew/Cellar/root/6.34.08_1/include/root/TIsAProxy.h \
  /opt/homebrew/Cellar/root/6.34.08_1/include/root/TVirtualIsAProxy.h \
  /opt/homebrew/Cellar/root/6.34.08_1/include/root/TArrayD.h \
  /opt/homebrew/Cellar/root/6.34.08_1/include/root/TArray.h \
  /opt/homebrew/Cellar/root/6.34.08_1/include/root/TArrayI.h \
  /opt/homebrew/Cellar/root/6.34.08_1/include/root/TAttFill.h \
  /opt/homebrew/Cellar/root/6.34.08_1/include/root/TAttLine.h \
  /opt/homebrew/Cellar/root/6.34.08_1/include/root/TAttMarker.h \
  /opt/homebrew/Cellar/root/6.34.08_1/include/root/TClass.h \
  /opt/homebrew/Cellar/root/6.34.08_1/include/root/TDictionary.h \
  /opt/homebrew/Cellar/root/6.34.08_1/include/root/TNamed.h \
  /opt/homebrew/Cellar/root/6.34.08_1/include/root/TObject.h \
  /opt/homebrew/Cellar/root/6.34.08_1/include/root/TStorage.h \
  /opt/homebrew/Cellar/root/6.34.08_1/include/root/TVersionCheck.h \
  /opt/homebrew/Cellar/root/6.34.08_1/include/root/RVersion.h \
  /opt/homebrew/Cellar/root/6.34.08_1/include/root/TString.h \
  /opt/homebrew/Cellar/root/6.34.08_1/include/root/TMathBase.h \
  /opt/homebrew/Cellar/root/6.34.08_1/include/root/ROOT/TypeTraits.hxx \
  /opt/homebrew/Cellar/root/6.34.08_1/include/root/ESTLType.h \
  /opt/homebrew/Cellar/root/6.34.08_1/include/root/TObjArray.h \
  /opt/homebrew/Cellar/root/6.34.08_1/include/root/TSeqCollection.h \
  /opt/homebrew/Cellar/root/6.34.08_1/include/root/TCollection.h \
  /opt/homebrew/Cellar/root/6.34.08_1/include/root/TIterator.h \
  /opt/homebrew/Cellar/root/6.34.08_1/include/root/TVirtualRWMutex.h \
  /opt/homebrew/Cellar/root/6.34.08_1/include/root/TVirtualMutex.h \
  /opt/homebrew/Cellar/root/6.34.08_1/include/root/ROOT/RRangeCast.hxx \
  /opt/homebrew/Cellar/root/6.34.08_1/include/root/ROOT/RSpan.hxx \
  /opt/homebrew/Cellar/root/6.34.08_1/include/root/ROOT/span.hxx \
  /opt/homebrew/Cellar/root/6.34.08_1/include/root/TDataType.h \
  /opt/homebrew/Cellar/root/6.34.08_1/include/root/TDirectory.h \
  /opt/homebrew/Cellar/root/6.34.08_1/include/root/TUUID.h \
  /opt/homebrew/Cellar/root/6.34.08_1/include/root/TList.h \
  /opt/homebrew/Cellar/root/6.34.08_1/include/root/TBuffer.h \
  /opt/homebrew/Cellar/root/6.34.08_1/include/root/Bytes.h \
  /opt/homebrew/Cellar/root/6.34.08_1/include/root/TVirtualTreePlayer.h \
  /opt/homebrew/Cellar/root/6.34.08_1/include/root/TBranch.h \
  /opt/homebrew/Cellar/root/6.34.08_1/include/root/TBranchCacheInfo.h \
  /opt/homebrew/Cellar/root/6.34.08_1/include/root/TBits.h \
  /opt/homebrew/Cellar/root/6.34.08_1/include/root/TChain.h

include/NtupleReader.hh:

/opt/homebrew/Cellar/root/6.34.08_1/include/root/TTree.h:

/opt/homebrew/Cellar/root/6.34.08_1/include/root/Compression.h:

/opt/homebrew/Cellar/root/6.34.08_1/include/root/RtypesCore.h:

/opt/homebrew/Cellar/root/6.34.08_1/include/root/ROOT/RConfig.hxx:

/opt/homebrew/Cellar/root/6.34.08_1/include/root/ROOT/../RVersion.h:

/opt/homebrew/Cellar/root/6.34.08_1/include/root/ROOT/RVersion.hxx:

/opt/homebrew/Cellar/root/6.34.08_1/include/root/RConfigure.h:

/opt/homebrew/Cellar/root/6.34.08_1/include/root/DllImport.h:

/opt/homebrew/Cellar/root/6.34.08_1/include/root/ROOT/TIOFeatures.hxx:

/opt/homebrew/Cellar/root/6.34.08_1/include/root/Rtypes.h:

/opt/homebrew/Cellar/root/6.34.08_1/include/root/strtok.h:

/opt/homebrew/Cellar/root/6.34.08_1/include/root/strlcpy.h:

/opt/homebrew/Cellar/root/6.34.08_1/include/root/snprintf.h:

/opt/homebrew/Cellar/root/6.34.08_1/include/root/TGenericClassInfo.h:

/opt/homebrew/Cellar/root/6.34.08_1/include/root/TSchemaHelper.h:

/opt/homebrew/Cellar/root/6.34.08_1/include/root/TIsAProxy.h:

/opt/homebrew/Cellar/root/6.34.08_1/include/root/TVirtualIsAProxy.h:

/opt/homebrew/Cellar/root/6.34.08_1/include/root/TArrayD.h:

/opt/homebrew/Cellar/root/6.34.08_1/include/root/TArray.h:

/opt/homebrew/Cellar/root/6.34.08_1/include/root/TArrayI.h:

/opt/homebrew/Cellar/root/6.34.08_1/include/root/TAttFill.h:

/opt/homebrew/Cellar/root/6.34.08_1/include/root/TAttLine.h:

/opt/homebrew/Cellar/root/6.34.08_1/include/root/TAttMarker.h:

/opt/homebrew/Cellar/root/6.34.08_1/include/root/TClass.h:

/opt/homebrew/Cellar/root/6.34.08_1/include/root/TDictionary.h:

/opt/homebrew/Cellar/root/6.34.08_1/include/root/TNamed.h:

/opt/homebrew/Cellar/root/6.34.08_1/include/root/TObject.h:

/opt/homebrew/Cellar/root/6.34.08_1/include/root/TStorage.h:

/opt/homebrew/Cellar/root/6.34.08_1/include/root/TVersionCheck.h:

/opt/homebrew/Cellar/root/6.34.08_1/include/root/RVersion.h:

/opt/homebrew/Cellar/root/6.34.08_1/include/root/TString.h:

/opt/homebrew/Cellar/root/6.34.08_1/include/root/TMathBase.h:

/opt/homebrew/Cellar/root/6.34.08_1/include/root/ROOT/TypeTraits.hxx:

/opt/homebrew/Cellar/root/6.34.08_1/include/root/ESTLType.h:

/opt/homebrew/Cellar/root/6.34.08_1/include/root/TObjArray.h:

/opt/homebrew/Cellar/root/6.34.08_1/include/root/TSeqCollection.h:

/opt/homebrew/Cellar/root/6.34.08_1/include/root/TCollection.h:

/opt/homebrew/Cellar/root/6.34.08_1/include/root/TIterator.h:

/opt/homebrew/Cellar/root/6.34.08_1/include/root/TVirtualRWMutex.h:

/opt/homebrew/Cellar/root/6.34.08_1/include/root/TVirtualMutex.h:

/opt/homebrew/Cellar/root/6.34.08_1/include/root/ROOT/RRangeCast.hxx:

/opt/homebrew/Cellar/root/6.34.08_1/include/root/ROOT/RSpan.hxx:

/opt/homebrew/Cellar/root/6.34.08_1/include/root/ROOT/span.hxx:

/opt/homebrew/Cellar/root/6.34.08_1/include/root/TDataType.h:

/opt/homebrew/Cellar/root/6.34.08_1/include/root/TDirectory.h:

/opt/homebrew/Cellar/root/6.34.08_1/include/root/TUUID.h:

/opt/homebrew/Cellar/root/6.34.08_1/include/root/TList.h:

/opt/homebrew/Cellar/root/6.34.08_1/include/root/TBuffer.h:

/opt/homebrew/Cellar/root/6.34.08_1/include/root/Bytes.h:

/opt/homebrew/Cellar/root/6.34.08_1/include/root/TVirtualTreePlayer.h:

/opt/homebrew/Cellar/root/6.34.08_1/include/root/TBranch.h:

/opt/homebrew/Cellar/root/6.34.08_1/include/root/TBranchCacheInfo.h:

/opt/homebrew/Cellar/root/6.34.08_1/include/root/TBits.h:

/opt/homebrew/Cellar/root/6.34.08_1/include/root/TChain.h:
